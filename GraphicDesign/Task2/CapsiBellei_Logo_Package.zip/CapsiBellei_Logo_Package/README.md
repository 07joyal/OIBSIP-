# Capsi Bellei — Logo Package

## What's inside
- **SVG/** — vector source files (icon-only + full lockup with wordmark), in all 3 colourways
- **PDF/** — vector files openable directly in Illustrator/Affinity as source art
- **PNG_transparent/** — transparent-background exports, 1200×1200 (icon) / 1200×1450 (lockup) — exceeds the 1000×1000 minimum
- **Preview/** — flattened previews on a background so you can see each variant at a glance (not deliverable files, just for review)

Each folder contains three variants: **full colour** (brand green), **monochrome** (black), and **reversed** (white, for use on dark/colour backgrounds).

## Design rationale
The mark is three overlapping circles forming a clover/trefoil — a nod to clustered peppers (Capsi) and a leaf motif, built entirely from simple geometric strokes for maximum scalability down to favicon size. At its centre, the negative space reveals a small smiling face, giving the brand warmth and a "fresh, friendly produce" personality without adding a single extra shape. Deep green was chosen as the primary colour for its direct association with freshness and plants, with pure black and white variants ensuring the mark stays legible on packaging, stamps, or dark backgrounds. The wordmark uses Poppins Bold — a rounded, geometric sans that echoes the soft curves of the icon — set in tight, confident caps for a friendly-but-sturdy grocery-brand voice.

## Typography
Wordmark set in **Poppins Bold** (Google Fonts, open-source), chosen for its rounded terminals that visually pair with the icon's curves while staying highly legible at small sizes.
